<?php
$name = $_POST['name'];
$email = $_POST['email'];
$mobile = $_POST['mobile'];
$message = $_POST['message'];
$formcontent="From: $name \n E-mail: $email \n Mobile: $mobile \n Message: $message";
$recipient = "ahmedshaaban00@outlook.com";
$subject = "Blend Contact Message / $name";
$header = "From: $email";
mail($recipient, $subject, $formcontent, $header) or die("Error!");
echo "Thank You!";
?>
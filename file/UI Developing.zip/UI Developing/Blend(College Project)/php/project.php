<?php
$name = $_POST['name'];
$email = $_POST['email'];
$website = $_POST['website'];
$timeline = $_POST['timeline'];
$budget = $_POST['budget'];
$service = $_POST['service'];
$message = $_POST['message'];
$formcontent="From: $name \n E-mail: $email \n Website: $website \n Timeline: $timeline \n Budget: $budget$ \n Service Needed: $service \n Message: $message";
$recipient = "ahmedshaaban00@outlook.com";
$subject = "Blend Project Request / $name";
$header = "From: $email";
mail($recipient, $subject, $formcontent, $header) or die("Error!");
echo "Thank You!";
?>